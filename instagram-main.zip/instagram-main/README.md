> # **Instagram Phishing Page**

❗ **Do not forget to not use it for malicious purposes, it's only for educational purposes.**<br/>
❗ **You are solely responsible for your actions, that's obviously not me.**<br/>
<br/>
> ### **How to use:**
**- My Instagram phishing page is really easy to use, you only have to replace WEBHOOK on line 101 by your Discord webhook :**<br/>
![webhook](https://user-images.githubusercontent.com/81310818/123550149-869fee00-d76c-11eb-9938-34a444eb00e1.PNG)<br>
**- Next you upload it in your website (like netlify or 000webhost, they are free)**<br>
**- When someone will login you will receive his credentials and he will be redirected to a funny video on Instagram for example.**<br/>
**- You can edit the redirection link by editing it on line 108 in the js part in HTML code.**<br/>
![image](https://user-images.githubusercontent.com/81310818/123550314-4d1bb280-d76d-11eb-8ca0-cec48b286461.png)<br>

> **V E N A X**
